/* 
 * CSCI3240: Project 2
 * 
 * 
 * Project2.c - Source file with your solutions to the Lab.
 *          This is the file you will submit in the D2L -> Project2 dropbox.
 *
 *   Please make sure you don't include the main function in this file. Graders will use a separate `.c` file containing the `main` function to test your Mystery functions.  
 *	 If you'd like to test your code, you can create a separate `main.c` file that includes the `main` function, which calls the Mystery functions defined in this `Project2.c` file.
 *   You don't need to submit the 'main.c' file.
 *	 Make sure you have insightful comments in your code. 
 *   
 * 
 */


long MysteryFunction1(long a, int b){

   //TODO
   //check assembly code for MysteryFunction1 in project2.s
}


unsigned int MysteryFunction2(unsigned int num)
{
     //TODO
   //check assembly code for MysteryFunction2 in project2.s
 
}


long MysteryFunction3(long *a, int n){
   //TODO
   //check assembly code for MysteryFunction3 in project2.s
}

int MysteryFunction4(unsigned long n)
{
      //TODO
   //check assembly code for MysteryFunction4 in project2.s

}



unsigned int MysteryFunction5(unsigned int A, unsigned int B)
{
  //TODO
   //check assembly code for MysteryFunction5 in project2.s

}

// Do not add a main function here.

